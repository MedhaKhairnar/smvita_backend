export const logoNegative = []
